
public class Kamion extends Vozilo {
	
	private int nosivost;

	public int getNosivost() {
		return nosivost;
	}

	public void setNosivost(int nosivost) {
		this.nosivost = nosivost;
	}

	public Kamion(String marka, String model, int kubikaza, int godiste, int nosivost) {
		super(marka, model, kubikaza, godiste);
		this.setNosivost(nosivost);
	}
	
	public Kamion() {
		this(null, null, 0, 0, 0);
	}
	
	@Override
	public String toString() {
		return "{\n'klasa': 'Kamion',\n'marka': '" + getMarka() + "',\n'model': '" + getModel() + ",'\n'kubikaza': " + getKubikaza()
				+ ",\n'godiste': " + getGodiste() + ",\n'nosivost': " + getNosivost() + "\n}";
	}
	
	@Override
	public float dajCijenuRegistracije() {
		return (this.getKubikaza() / (float) 10.0 + (2025 - this.getGodiste()) * 10) * Vozilo.getOsnovicaZaRegistraciju() + 30 * this.getNosivost();
	}
	

}
