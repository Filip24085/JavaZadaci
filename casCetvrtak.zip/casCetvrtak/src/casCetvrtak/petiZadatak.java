package casCetvrtak;

import java.util.Scanner;

public class petiZadatak {

	public static void main(String[] args) {


		Scanner sc = new Scanner(System.in);
		
		double xH = sc.nextDouble(), yH = sc.nextDouble(), xK = sc.nextDouble(), yK = sc.nextDouble();
		
		double xB= xK+2;
		double yB = yK-3;
		
		double hrastBlago = Math.sqrt(Math.pow((yH-yB), 2)+Math.pow((xB-xH), 2));
		
		System.out.printf("Vazduana linija od hrasta do blaga je %.2f.%n", hrastBlago);
		
		sc.close();


	}

}
