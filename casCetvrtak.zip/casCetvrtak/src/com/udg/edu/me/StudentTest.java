package com.udg.edu.me;

public class StudentTest {

	public static void main(String[] args) {

		Student s1 = new Student("Marko", "Markovic", "25/001", "Oktoih 1, 81000 Podgorica", 65, true);
		System.out.println(s1.toString());

	}

}
