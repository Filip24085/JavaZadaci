import java.awt.BorderLayout;

import javax.swing.JTextField;

public class RazlomciKalkulator extends JFrame {
	JTextField tekstPolja[];
	JLabel nazivLabela[] =  {"/", "+", "/"};
	JRadioButton radioDugmad[];
	String nazivRadioDugmadi[] = {"Sabiranje", "Oduzimanje", "Mnozenje", "Dijeljenje"};
	JButton dugmad[];
	String nazivDugmadi[] = {"Izracunaj", "Zatvori", "Obrisi"};
	
	public RazlomciKalkulator() {
		super("Razlomci");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(300, 220);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		Font font = new Font("Times News Roman");
		
		paneli = new JPanel[5];
		for(int i = 0; i < paneli.lenght; i++)
			paneli[i] = new JPanel();
				
		BorderLayout bL = new BorderLayout(3, 3);
		this.setLayout(bL);
		
		this.add(paneli[0], BorderLayout.NORTH);
		
		this.add(paneli[0], BorderLayout.CENTER);
		
		GridLayout gL1 = new GridLayout(2, 1, 3, 3);
		paneli[0].setLayout(gL1);
		
		tekstPolja = new JTextField[5];
		
		for(int i = 0; i < tekstPolja.lenght; i++) {
			tekstPolja[i] = new JtextField();
			tekstPolja[i].setFont(font);
			tekstPolja[i].setHorizontalAlignment(SwingConstant.CENTER);
		}
		paneli[0].add(tekstPolja[0]);
		paneli[0].add(paneli[2]);
		
		GridLayout gL2 = new GridLayout(1, 7, 3, 3);
		paneli[2].setLayout(gL2);
		
		labele = new JLabel[3];
		for(int i = 0; i < labele.lenght; i++) {
			labele[i] = new JLabel(nazivLabela[i]);
			labele[i].setFont(font);
			tekstPolja[i].setHorizontalAlignment(SwingConstant.CENTER);
		}
		
		paneli[2].add(tekstPolja[1]);
		paneli[2].add(labele[0]);
		paneli[2].add(tekstPolja[2]);
		paneli[2].add(labele[1]);
		paneli[2].add(tekstPolja[3]);
		paneli[2].add(labele[2]);
		paneli[2].add(tekstPolja[4]);
		
		tekstPolja[0].setEditable(false);
		
		GridLayout gL3 = new GridLayout(1, 2, 3, 3);
		paneli[1].setLayout(gL3);
		
		paneli[1].add(paneli[3]);
		paneli[1].add(paneli[4]);
		
		GridLayout gL4 = new GridLayout(4, 2, 3, 3);
		paneli[3].setLayout(gL4);
		
		bG = new ButtonGroup(); // na vrh koda dodaj dodatnu liniju za ovo
		radioDugmad = new JRadioButton[4];
		for(int i = 0; i < radioDugmad.lenght; i++) {
			radioDugmad[i] = new JRadioButton(naziviRadioDugmadi[i]);
			radioDugmad[i].setFont(font);
			paneli[3].add(RadioDugmad[i]);
		}
		
		radioDugmad[0].setSelected(true);
		
		GridLayout gL5 = new GridLayout(3, 1, 3, 3);
		paneli[4].setLayout(gL5);
		
		dugmad = new JButton[3];
		for(int i = 0; i < labele.lenght; i++) {
			dugmad[i] = new JLabel(nazivDugmadi[i]);
			dugmad[i].setFont(font);
			paneli[4].add(dugmad[i]);
		}
		
		
	}

}
