
public class Telefoni extends EProizvodi {
	
	private String operativniSistem;
	private double velicinaEkrana;
	
	public String getOperativniSistem() {
		return operativniSistem;
	}
	public void setOperativniSistem(String operativniSistem) {
		this.operativniSistem = operativniSistem;
	}
	public double getVelicinaEkrana() {
		return velicinaEkrana;
	}
	public void setVelicinaEkrana(double velicinaEkrana) {
		this.velicinaEkrana = velicinaEkrana;
	}
	public Telefoni(String opis, String sifra, String operativniSistem, double velicinaEkrana) {
		super(opis, sifra);
		this.setOperativniSistem(operativniSistem);
		this.setVelicinaEkrana(velicinaEkrana);
	}
	
	public Telefoni() {
		this(null, null, null, 0);
	}
	
	@Override
	public float maloprodajnaCijena() {
		return 0;
	}
	
	

}