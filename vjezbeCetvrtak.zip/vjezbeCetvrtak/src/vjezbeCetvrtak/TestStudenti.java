package vjezbeCetvrtak;

public enum Studenti {
	PETAR_PETROVIC(8, 9, 10),
	MILICA_MILIC(9, 9, 8),
	IVAN_IVANOVIC(10, 10, 9),
	JOVANA_JOVANOVIC(7, 8, 8),
	MARKO_MARKOVIC(6, 7, 8);
	
	private final int ocjena1;
	private final int ocjena2;
	private final int ocjena3;
	
	private Studenti(int ocjena1, int ocjena2, int ocjena3) {
		this.ocjena1 = ocjena1;
		this.ocjena2 = ocjena2;
		this.ocjena3 = ocjena3;
	}
	
	@Override
	public String toString()
	String ime
	
	
}
