package vjezbeCetvrtak;

import java.util.ArrayList;

public class AutoServis {
	public static ArrayList<Auto> neregistrovaniKojiSeMoguRegistrovati(ArrayList<Auto> auta) {
		ArrayList<Auto> lista = new ArrayList<>();
		
	}
}
