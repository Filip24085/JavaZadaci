package vjezbeSrijeda;

import java.util.Scanner;

public class treciZadatak {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String rijec = sc.nextLine();
        
        boolean nadjeno=false;
        
        for(int i=0; i<rijec.length()-1; i++)
        	if (rijec.charAt(i) == rijec.charAt(i+1)) {
                System.out.println("Dva uzastopna slova: " + rijec.charAt(i));
            }
        System.out.println("Nema dva uzastopna ista slova.");

    }
}
