
public class Racunari extends EProizvodi {
	
	private String procesor;
	private int memorija;
	
	public String getProcesor() {
		return procesor;
	}
	public void setProcesor(String procesor) {
		this.procesor = procesor;
	}
	public int getMemorija() {
		return memorija;
	}
	public void setMemorija(int memorija) {
		this.memorija = memorija;
	}
	
	public Racunari(String opis, String sifra, String procesor, int memorija) {
		super(opis, sifra);
		this.setProcesor(procesor);
		this.setMemorija(memorija);
	}
	
	public Racunari() {
		this(null, null, null, 0);
	}
	
	@Override
	public float maloprodajnaCijena() {
		return (float) (EProizvodi.getUvoznaCijena() * 1.05);
	}
	
	

}
