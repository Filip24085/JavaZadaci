
public interface Trosak {
	
	public float obracunajTrosak();
	
}
