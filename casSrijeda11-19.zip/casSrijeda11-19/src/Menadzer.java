
public class Menadzer extends Zaposleni implements Trosak {
	
	private float koeficijentOdgovornosti;
	
	

	public Menadzer(String imePrezime, String id, float osnovnaPlata, float koeficijentOdgovornosti) {
		super(imePrezime, id, osnovnaPlata);
		this.setKoeficijentOdgovornosti(koeficijentOdgovornosti);
	}
	
	public Menadzer() {
		this(null, null, 0, 0);
	}

	public float getKoeficijentOdgovornosti() {
		return koeficijentOdgovornosti;
	}

	public void setKoeficijentOdgovornosti(float koeficijentOdgovornosti) {
		this.koeficijentOdgovornosti = koeficijentOdgovornosti;
	}
	
	@Override
	public float obracunajTrosak() {
		return this.izracunajPlatu();
	}

	@Override
	public float izracunajPlatu() {
		return this.getOsnovnaPlata() * this.getKoeficijentOdgovornosti();
	}
	
	@Override
	public String toString() {
		return "{'klasa': 'SluzbenikSaltera', 'brojObradjenihZahtjeva': '" + brojObradjenihZahtjeva + "', 'bonusPoZahtjevu': '"
				+ bonusPoZahtjevu + "', 'imePrezime': '" + getImePrezime() + "', 'id': '" + getId()
				+ "', 'osnovnaPlata': '" + getOsnovnaPlata() + "'}";
	}

}
