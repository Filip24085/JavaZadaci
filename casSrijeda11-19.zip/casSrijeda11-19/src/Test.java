
public class Test {

	public static void main(String[] args) {
		ArrayList<Zaposleni> x = new ArrayList<Zaposleni>();
		
		x.add(new SluzbenikSaltera("Pera Peric", "ID001", 600, 100, 20));
		x.add(new SluzbenikSaltera("John Doe", "ID002", 800, 120, 10));
		x.add(new TehnickaPodrska("Pera Peric", "ID003", 1200, 10, (float)2.1));
		x.add(new SluzbenikSaltera("Pera Peric", "ID001", 600, 100, 20));

	}

}
