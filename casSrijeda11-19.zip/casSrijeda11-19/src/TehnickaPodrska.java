
public class TehnickaPodrska extends Zaposleni implements Trosak {
	
	private int brojRijesenihTiketa;
	private float koeficijentUcinka;
	
	

	public TehnickaPodrska(String imePrezime, String id, float osnovnaPlata, int brojRijesenihTiketa,
			float koeficijentUcinka) {
		super(imePrezime, id, osnovnaPlata);
		this.setBrojRijesenihTiketa(brojRijesenihTiketa);
		this.setKoeficijentUcinka(koeficijentUcinka);
	}
	
	public TehnickaPodrska() {
		this(null, null, 0, 0, 0);
	}
	

	public int getBrojRijesenihTiketa() {
		return brojRijesenihTiketa;
	}

	public void setBrojRijesenihTiketa(int brojRijesenihTiketa) {
		this.brojRijesenihTiketa = brojRijesenihTiketa;
	}

	public float getKoeficijentUcinka() {
		return koeficijentUcinka;
	}

	public void setKoeficijentUcinka(float koeficijentUcinka) {
		this.koeficijentUcinka = koeficijentUcinka;
	}

	@Override
	public float obracunajTrosak() {
		return this.izracunajPlatu();
	}

	@Override
	public float izracunajPlatu() {
		return this.getOsnovnaPlata() * this.getKoeficijentUcinka();
	}
	
	@Override
	public String toString() {
		return "{'klasa': 'SluzbenikSaltera', 'brojObradjenihZahtjeva': '" + brojObradjenihZahtjeva + "', 'bonusPoZahtjevu': '"
				+ bonusPoZahtjevu + "', 'imePrezime': '" + getImePrezime() + "', 'id': '" + getId()
				+ "', 'osnovnaPlata': '" + getOsnovnaPlata() + "'}";
	}

}
