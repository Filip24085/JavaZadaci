
public class SluzbenikSaltera extends Zaposleni implements Trosak {
	
	private int brojObradjenihZahtjeva;
	private float bonusPoZahtjevu;

	public SluzbenikSaltera(String imePrezime, String id, float osnovnaPlata, int brojObradjenihZahtjeva,
			float bonusPoZahtjevu) {
		super(imePrezime, id, osnovnaPlata);
		this.setBrojObradjenihZahtjeva(brojObradjenihZahtjeva);
		this.setBonusPoZahtjevu(bonusPoZahtjevu);
	}
	
	public SluzbenikSaltera() {
		this(null, null, 0, 0, 0);
	}

	public int getBrojObradjenihZahtjeva() {
		return brojObradjenihZahtjeva;
	}

	public void setBrojObradjenihZahtjeva(int brojObradjenihZahtjeva) {
		this.brojObradjenihZahtjeva = brojObradjenihZahtjeva;
	}

	public float getBonusPoZahtjevu() {
		return bonusPoZahtjevu;
	}

	public void setBonusPoZahtjevu(float bonusPoZahtjevu) {
		this.bonusPoZahtjevu = bonusPoZahtjevu;
	}

	@Override
	public float obracunajTrosak() {
		return this.izracunajPlatu();
	}

	@Override
	public float izracunajPlatu() {
		return this.getOsnovnaPlata() + this.getBrojObradjenihZahtjeva() * this.getBonusPoZahtjevu();
	}

	@Override
	public String toString() {
		return "{'klasa': 'SluzbenikSaltera', 'brojObradjenihZahtjeva': '" + brojObradjenihZahtjeva + "', 'bonusPoZahtjevu': '"
				+ bonusPoZahtjevu + "', 'imePrezime': '" + getImePrezime() + "', 'id': '" + getId()
				+ "', 'osnovnaPlata': '" + getOsnovnaPlata() + "'}";
	}
	
}
